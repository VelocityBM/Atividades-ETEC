function calculo() {
   var num1 = parseFloat(document.getElementById('num1').value);
   var num2 = parseFloat(document.getElementById('num2').value);
   var operador = document.querySelector('input[name="operation"]:checked').value;
   var result;

   switch(operador) {
       case "add":
           result = num1 + num2;
           break;
       case "subtrair":
           result = num1 - num2;
           break;
       case "multiplicar":
           result = num1 * num2;
           break;
       case "dividir":
           if (num2 !== 0) {
               result = num1 / num2;
           } else {
               result = "Não é possível dividir por zero!";
           }
           break;
       default:
           result = "Operação inválida";
   }

   document.getElementById('result').value = result;
}
