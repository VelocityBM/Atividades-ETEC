#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    float vValorComp=0.0, vVenda=0.0, vLucro=0;0;
    
    printf("Digite o valor da compra: ");
    scanf("%f", &vValorComp);
    
    if (vValorComp < 200) {
        vLucro= 0.5; 
    } else {
        vLucro= 0.3; 
    }
    vVenda= vValorComp*(1+vLucro);

    printf("O valor de venda �: %.2f", vVenda);

    return 0;
}
