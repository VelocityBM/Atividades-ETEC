#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    float vSalario = 0.0, vReajustePcnt = 0.0, vReajusteValor = 0.0, vSalarioFinal = 0.0;

    printf("Digite o sal�rio: ");
    scanf("%f", &vSalario);

    if (vSalario <= 1000.00) {
        vReajustePcnt = 0.2;
    } else if (vSalario <= 1500.00) {
        vReajustePcnt = 0.15;
    } else if (vSalario <= 2500.00) {
        vReajustePcnt = 0.1;
    } else {
        vReajustePcnt = 0.05;
    }

    vReajusteValor = vSalario * vReajustePcnt;
    vSalarioFinal = vSalario + vReajusteValor;

    printf("Sal�rio sem reajuste: R$ %.2f\n", vSalario);
    printf("Percentual do reajuste: %.f%%\n", vReajustePcnt*100);
    printf("Valor do reajuste: R$ %.2f\n", vReajusteValor);
    printf("Novo sal�rio: R$ %.2f\n", vSalarioFinal);

    return 0;
}
