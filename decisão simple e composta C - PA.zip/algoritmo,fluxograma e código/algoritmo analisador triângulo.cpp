#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    float vLado1=0.0, vLado2=0.0, vLado3=0.0;

    printf("Digite o tamanho do primeiro lado do tri�ngulo: ");
    scanf("%f", &vLado1);

    printf("Digite o tamanho do segundo lado do tri�ngulo: ");
    scanf("%f", &vLado2);

    printf("Digite o tamanho do terceiro lado do tri�ngulo: ");
    scanf("%f", &vLado3);

    if ((vLado1 + vLado2 > vLado3) && (vLado1 + vLado3 > vLado2) && (vLado2 + vLado3 > vLado1)) {
        if (lado1 == lado2 && lado2 == lado3) {
            printf("Os lados formam um tri�ngulo equil�tero.\n");
        } else if (vLado1 == vLado2 || vLado1 == vLado3 || vLado2 == vLado3) {
            printf("Os lados formam um tri�ngulo is�sceles.\n");
        } else {
            printf("Os lados formam um tri�ngulo escaleno.\n");
        }
    } else {
        printf("Os lados n�o formam um tri�ngulo.\n");
    }

    return 0;
}
