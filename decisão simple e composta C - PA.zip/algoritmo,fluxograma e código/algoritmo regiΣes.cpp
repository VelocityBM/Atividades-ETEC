#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    int vCodigo=0.0;

    printf("Insira o c�digo desejado para obter uma regi�o: ");
    scanf("%i", &vCodigo);

    if (vCodigo == 1) {
        printf("\nSua regi�o � o Sul");
    } else if (vCodigo == 2) {
        printf("\nSua regi�o � o Sudeste");
    } else if (vCodigo == 3) {
        printf("\nSua regi�o � o Centro-Oeste");
    } else if (vCodigo == 4) {
        printf("\nSua regi�o � o Norte");
    } else if (vCodigo == 5) {
        printf("\nSua regi�o � o Nordeste");
    } else {
        printf("N�mero inv�lido!");
        return 0;
    }
 
    printf("\nFim do Programa");

    return 0;
}
