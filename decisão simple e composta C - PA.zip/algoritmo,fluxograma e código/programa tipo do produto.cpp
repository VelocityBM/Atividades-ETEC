#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"portuguese");
		printf("Esse programa te informar� qual � o tipo do seu item. \n\n");
		int vCodigo=0.0;
		printf("Qual � o c�digo do item? ");
		scanf("%i",&vCodigo);
		if(vCodigo==1){
				printf("\nEste item � um alimento perec�vel.");
			}
			else{
				if(vCodigo>=2 && vCodigo<=4){
				printf("\nEste item � um alimento n�o perec�vel.");
				}
				else{
					if(vCodigo>=5 && vCodigo<=6){
					printf("Este item � vestu�rio.");
					}
					else{
						printf("C�digo inv�lido!");
					}
				}
			}
	
					
			printf("\nFim do programa");
			
		return 0; }
