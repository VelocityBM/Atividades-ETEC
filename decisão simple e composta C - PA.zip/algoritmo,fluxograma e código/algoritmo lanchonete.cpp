#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    int vCodigo, vQuantidade;
    float vValor = 0.0;

    printf("Insira o c�digo do produto: ");
    scanf("%i", &vCodigo);

    printf("Digite a quantidade desejada: ");
    scanf("%i", &vQuantidade);

    if (vCodigo == 100) {
        vValor = 12.90;
    } else if (vCodigo == 101) {
        vValor = 14.10;
    } else if (vCodigo == 102) {
        vValor = 16.50;
    } else if (vCodigo == 103) {
        vValor = 28.00;
    } else if (vCodigo == 104) {
        vValor = 32.00;
    } else if (vCodigo == 105) {
        vValor = 7.00;
    } else {
        printf("Este c�digo � inv�lido!\n");
        return 0;
    }
    
    vValor=vValor*vQuantidade;

    printf("O valor do seu pedido ser�: R$ %.2f\n", vValor);

    return 0;
}
