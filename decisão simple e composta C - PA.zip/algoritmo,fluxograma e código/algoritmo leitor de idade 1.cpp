#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL,"portuguese");
		printf("Esse programa te informar� se voc� � uma crian�a, adolescente ou adulto. \n\n");
		float vIdade=0.0;
		printf("Quantos anos voc� tem? ");
		scanf("%f", &vIdade);
			if(vIdade>20){
				printf("\nVoc� � um adulto.");
			}
			else{
				if(vIdade<=20 && vIdade>=14){
				printf("Voc� � um adolescente.");
				}
				else{
					printf("Voc� � uma crian�a.");
				}
			}
	
					
			
			
		return 0; }
