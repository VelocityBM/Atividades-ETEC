#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"portuguese");

    float vCompra, vDesconto = 0.0, vDescontoValor, vCompraDescontada;

    printf("Digite o valor da compra: R$ ");
    scanf("%f", &vCompra);

    if (vCompra <= 100) {
        vDesconto = 0.02; 
    } else if (vCompra > 100 && vCompra <= 300) {
        vDesconto = 0.05;
    } else if (vCompra > 300 && vCompra <= 700) {
        vDesconto = 0.09;
    } else if (vCompra > 700 && vCompra <= 1200) {
        vDesconto = 0.12;
    } else if (vCompra > 1200) {
        vDesconto = 0.15; 
    }

    vDescontoValor = vCompra * vDesconto;
    vCompraDescontada = vCompra - vDescontoValor;

    printf("O valor do desconto � de R$ %.2f\n", vDescontoValor);
    printf("O valor final da sua compra com desconto � R$ %.2f\n", vCompraDescontada);

    return 0;
}
