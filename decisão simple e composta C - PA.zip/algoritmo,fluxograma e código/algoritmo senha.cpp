#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "portuguese");

    printf("Este sistema � protegido por senha\n\n");
    
    int vSenha;
    printf("Insira a senha: ");
    scanf("%d", &vSenha);
    
    if (vSenha == 123456) {
        printf("\nAcesso permitido\n");
    } else {
        printf("\nVoc� n�o tem acesso ao sistema\n");
    }

    printf("\nFim do programa\n");
    
    return 0;
}
