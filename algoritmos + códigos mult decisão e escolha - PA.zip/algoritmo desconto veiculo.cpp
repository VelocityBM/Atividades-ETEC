#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
	setlocale(LC_ALL,"portuguese");
	printf("Programa para calcular o desconto em um ve�culo baseado na sua regi�o\n\n");
	int  vCod=0.0, vValorVclo=0.0, vDscnt=0.0, vValorFinal;
	printf("1-Sul\n2-Sudeste\n3-Centro Oeste\n4-Nordeste\n5-Norte\nEscolha sua regi�o:");
	scanf("%i",&vCod);
	switch (vCod){
		case 1:
			printf("\n\nDigite o valor do ve�culo para obter o valor descontado: ");
	        scanf("%i",&vValorVclo);
	        vDscnt=0.04*vValorVclo;
	        vValorFinal=vValorVclo-vDscnt;
	        printf("\nSua regi�o � o Sul.\nSeu desconto � de 4%%, salvando R$ %.i. \nO pre�o de seu ve�culo � R$ %.i .", vDscnt, vValorFinal);
	       
			break;
		case 2:
			printf("\n\nDigite o valor do ve�culo para obter o valor descontado: ");
	        scanf("%i",&vValorVclo);
	        vDscnt=0.06*vValorVclo;
	        vValorFinal=vValorVclo-vDscnt;
	        printf("\nSua regi�o � o Sudeste.\nSeu desconto � de 6%%, salvando R$ %.i. \nO pre�o de seu ve�culo � R$ %.i.", vDscnt, vValorFinal);
	       
			break;
		case 3:
			printf("\n\nDigite o valor do ve�culo para obter o valor descontado: ");
	        scanf("%i",&vValorVclo);
	        vDscnt=0.07*vValorVclo;
	        vValorFinal=vValorVclo-vDscnt;
	        printf("\n\nSua regi�o � o Centro Oeste.\nSeu desconto � de 7%%, salvando R$ %.i. \nO pre�o de seu ve�culo � R$ %.i.", vDscnt, vValorFinal);
	       
			break;
		case 4:
			printf("\n\nDigite o valor do ve�culo para obter o valor descontado: ");
	        scanf("%i",&vValorVclo);
	        vDscnt=0.09*vValorVclo;
	        vValorFinal=vValorVclo-vDscnt;
	        printf("\nSua regi�o � o Nordeste.\nSeu desconto � de 9%%, salvando R$ %.i. \nO pre�o de seu ve�culo � R$ %.i.", vDscnt, vValorFinal);
	       
			break;
		case 5:
			printf("\n\nDigite o valor do ve�culo para obter o valor descontado: ");
	        scanf("%i",&vValorVclo);
	        vDscnt=0.1*vValorVclo;
	        vValorFinal=vValorVclo-vDscnt;
	        printf("\nSua regi�o � o Norte.\nVoc� tem um desconto de 10%%, salvando R$ %.i. z\nO pre�o de seu ve�culo � R$ %.i.", vDscnt, vValorFinal);
	       
			break;
			
		default:
			printf("\nN�mero de regi�o incorreto!");
	}
	return 0;
}

