#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){
	setlocale(LC_ALL,"portuguese");
	printf("Programa para calcular o valor de venda de um produto\n\n");
	int  vTipoProduto=0;
	float vAcrescimo=0.0;
	printf("Digite o c�digo para obter seu item \n1-Computador\n2-TV\n3-Geladeira\n");
	scanf("%i",&vTipoProduto);
	switch (vTipoProduto){
		case 1:
			printf("\nDigite o valor do produto para calcular o valor de venda: ");
	        scanf("%f",&vAcrescimo);
		    vAcrescimo=vAcrescimo * 1.15;
			printf("\nEsse produto � um tipo de computador e precisa ser distribu�do no valor de R$ %.2f ", vAcrescimo);
			break;
		case 2:
			printf("\nDigite o valor do produto para calcular o valor de venda: ");
	        scanf("%f",&vAcrescimo);
		    vAcrescimo=vAcrescimo * 1.18;
		    printf("\nEsse produto � um tipo de TV e precisa ser distribu�do no valor de R$ %.2f", vAcrescimo)	;
		    break;
		case 3:
			printf("\nDigite o valor do produto para calcular o valor de venda: ");
	        scanf("%f",&vAcrescimo);
		    vAcrescimo=vAcrescimo * 1.07;
		    printf("\nEsse produto � um tipo de Geladeira e precisa ser distribu�do no valor de R$ %.2f", vAcrescimo);
		    break;
		default:
			printf("\nC�digo do produto inv�lido!")  ;
	}
	return 0;
}
